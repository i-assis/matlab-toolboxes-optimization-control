function vars = getvariables(X,var)
%GETVARIABLES (overloads sdpvar/getvariables on double)

% Author Johan L�fberg 
% $Id: getvariables.m,v 1.2 2004/07/02 08:17:30 johanl Exp $ 

vars = [];
