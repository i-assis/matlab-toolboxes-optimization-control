function y = ctranspose(X)
%PLUS (overloaded)

% Author Johan L�fberg
% $Id: ctranspose.m,v 1.1 2005/10/12 16:05:54 joloef Exp $

y = ctranspose(double(X));