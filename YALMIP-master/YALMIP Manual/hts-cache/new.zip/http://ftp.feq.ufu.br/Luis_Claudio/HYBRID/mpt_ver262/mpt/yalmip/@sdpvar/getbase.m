function Q=getbase(X)
%GETBASE Internal function to extract all base matrices

% Author Johan L�fberg 
% $Id: getbase.m,v 1.3 2005/10/12 16:05:54 joloef Exp $  

Q=double(X.basis);
  
  
      